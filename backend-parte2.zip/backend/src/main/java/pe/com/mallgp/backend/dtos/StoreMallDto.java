package pe.com.mallgp.backend.dtos;

public class StoreMallDto {
    private Integer capacity;

    public Integer getCapacity() {
        return capacity;
    }

    public void setCapacity(Integer capacity) {
        this.capacity = capacity;
    }

}
