package pe.com.mallgp.backend.entities;


import com.fasterxml.jackson.annotation.JsonIgnore;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.*;
import java.util.List;

@Entity
@Table(name="stores")
@Data
@NoArgsConstructor
public class Store {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    public Long id;

    public String name;

    public String category;

    @OneToMany(mappedBy = "store")
    @JsonIgnore
    private List<StoreMall> storeMalls;

    public Store(String name){this.name=name;}

    @OneToMany(mappedBy = "store")
    @JsonIgnore
    private List<ProductStore> productStores;


    @OneToMany(mappedBy = "store")
    @JsonIgnore
    private List<Offer>offers;

    public Store(String name, String category) {
        this.name = name;
        this.category = category;
    }
}
