package pe.com.mallgp.backend.controllers;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import pe.com.mallgp.backend.dtos.StoreMallDto;
import pe.com.mallgp.backend.entities.*;
import pe.com.mallgp.backend.repositories.AdminRepository;
import pe.com.mallgp.backend.repositories.MallRepository;
import pe.com.mallgp.backend.repositories.StoreMallRepository;
import pe.com.mallgp.backend.repositories.StoreRepository;

import java.util.List;

@RestController
@RequestMapping("/api")
public class StoreMallController {

    @Autowired
    private StoreMallRepository storeMallRepository;

    @Autowired
    private StoreRepository storeRepository;

    @Autowired
    private MallRepository mallRepository;

    @Autowired
    private AdminRepository adminRepository;

    @GetMapping("/store/mall")
    public ResponseEntity<List<StoreMall>> getAllStoreMall(){
        List<StoreMall> storeMalls = storeMallRepository.findAll();
        return new ResponseEntity<>(storeMalls, HttpStatus.OK);
    }

    @GetMapping("/store/mall/{id}")
    public ResponseEntity<StoreMall> getStoreMallById(@PathVariable("id") Long id){
        StoreMall storeMall=storeMallRepository.findById(id).get();
        return new ResponseEntity<>(storeMall, HttpStatus.OK);
    }

    @PostMapping("/store/{storeId}/mall/{mallId}/admin/{adminId}")
    public ResponseEntity<StoreMall> createStoreMall(@RequestBody StoreMallDto request, @PathVariable Long storeId, @PathVariable Long mallId, @PathVariable Long adminId){

        Store store = storeRepository.findById(storeId).get();
        Mall mall = mallRepository.findById(mallId).get();
        Admin admin = adminRepository.findById(adminId).get();

        StoreMall newStoreMall = storeMallRepository.save(new StoreMall(store, mall, request.getCapacity(), admin));

        return new ResponseEntity<>(newStoreMall, HttpStatus.CREATED);
    }

    @PutMapping("/store/mall/{id}")
    public ResponseEntity<StoreMall> updateStoreMall(@RequestBody StoreMallDto request, @PathVariable Long id){
        StoreMall storeMall = storeMallRepository.findById(id).get();

        storeMall.setCapacity(request.getCapacity());

        StoreMall newProductStore = storeMallRepository.save(storeMall);
        return new ResponseEntity<>(newProductStore, HttpStatus.OK);
    }

    @DeleteMapping("/store/mall/{id}")
    public ResponseEntity<StoreMall> deleteStoreMall(@PathVariable Long id){

        StoreMall storeMall = storeMallRepository.findById(id).get();

        storeMallRepository.deleteById(storeMall.getId());

        return new ResponseEntity<>(storeMall, HttpStatus.OK);
    }

}
