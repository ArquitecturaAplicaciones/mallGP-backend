package pe.com.mallgp.backend.dtos;


public class CreateProductStore {

    private Double price;
    private String restock;

    public Double getPrice() {
        return price;
    }

    public void setPrice(Double price) {
        this.price = price;
    }

    public String getRestock() {
        return restock;
    }

    public void setRestock(String restock) {
        this.restock = restock;
    }




}
